# Viktor Ilic — Personal Blog & Digital Identity Portfolio

Single-file HTML, CSS & Vanilla JavaScript portfolio built for GitHub Pages and school presentation.

## Publishing to GitHub Pages (100% Standalone!)
All images (including Viktor's portrait, hero backdrop, and blog covers) are **embedded directly inside `index.html`** as Base64 Data URIs (`EMBEDDED_IMAGES`).

1. Upload `index.html` to a GitHub repository (you can upload **only** `index.html`, or the entire folder — either way, all images work automatically with zero broken links!).
2. Go to **Settings -> Pages -> Deploy from a branch (`main` / `root`)**.
3. Open your live GitHub Pages URL!

*(The `assets/` folder is also included here as optional backup copies of the original `.jpg` files.)*

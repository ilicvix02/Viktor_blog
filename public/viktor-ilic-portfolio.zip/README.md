# Viktor Ilic — Personal Blog & Digital Identity

A responsive, accessible single-file HTML5, CSS3, and Vanilla JavaScript portfolio & personal blog featuring:
- Light & Dark Modes ("Obsidian Synth" & "Solar Prism") with WCAG AA+ contrast
- Dynamic JavaScript typewriter headline
- Interactive CSS + SVG neon portrait overlays
- Custom animated SVG brand crest & 8 interactive portfolio SVG artworks
- 3-post journal with modal reader, category filtering, animated skill bars, and validated contact form

## How to Upload to GitHub & Publish with GitHub Pages
1. Unzip `viktor-ilic-portfolio.zip`.
2. Create a new repository on GitHub (for example, `viktor-ilic-portfolio`).
3. Upload `index.html`, `README.md`, and the `assets/` folder to the root of your repository.
4. Go to **Settings -> Pages**, choose **Deploy from a branch** (`main` / `/ (root)`), and click **Save**.
